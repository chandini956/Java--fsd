package practiseproject;

import java.util.regex.*;
public class regularexpressions {
public static <provided> void main(String[] args) {
// TODO Auto-generated method stub
String pattern="[a-s]+";
String check="Prerana Mohapatra";
//create a pattern to be searched
Pattern a = Pattern.compile(pattern);
//search the pattern in "Prerana Mohapatra"
Matcher b = a.matcher(check);
//Finding string using find()method
while (b.find())
 // print starting and ending indexes of the pattern in the .substring() method provided by the check1 class
System.out.println(check.substring(b.start(),b.end()));
}
}

