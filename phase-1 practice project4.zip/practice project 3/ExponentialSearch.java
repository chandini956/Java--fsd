package practiseproject;
public class ExponentialSearch {
    public static void main(String[] args) {
        int[] array = {2, 5, 8, 12, 16, 23, 38, 45, 58, 67, 79, 82};
        int target = 16;
        int index = exponentialSearch(array, target);
        if (index != -1) {
            System.out.println("Element found at index " + index);
        } else {
            System.out.println("Element not found in the array.");
        }
    }
    public static int exponentialSearch(int[] array, int target) {
        int size = array.length;
        if (array[0] == target) {
            return 0;
        }
        int bound = 1;
        while (bound < size && array[bound] <= target) {
            bound *= 2;
        }
        int left = bound / 2;
        int right = Math.min(bound, size - 1);
        while (left <= right) {
            int mid = left + (right - left) / 2;
            if (array[mid] == target) {
                return mid;
            } else if (array[mid] < target) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return -1;
    }
}
