package practiseproject;


	import java.util.Scanner;

	public class LinearSearch {
	    public static void main(String[] args) {
	        int[] array = {2, 8, 15, 24, 36, 42, 50, 68, 75, 83};
	        try (Scanner sc = new Scanner(System.in)) {
				System.out.print("Enter the number to search: ");
				int target = sc.nextInt();
				int index = -1;
				
				for (int i = 0; i < array.length; i++) {
				    if (array[i] == target) {
				        index = i;
				        break;
				    }
				}
				
				if (index != -1) {
				    System.out.println("Element found at index " + index);
				} else {
				    System.out.println("Element not found in the array.");
				}
			}
	    }
	}

	