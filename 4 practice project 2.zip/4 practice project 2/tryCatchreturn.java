package practiseproject;

public class tryCatchreturn {
	

	int calc(){

	try {

	return 5;

	} 
	catch (Exception e) {

	return 10;
	}
	}

	public static void main(String[] args) {

	tryCatchreturn obj = new tryCatchreturn();

	System.out.println(obj.calc());

	}
	}

