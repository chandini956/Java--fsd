package practiseproject;

	import java.io.*;

	public class operations {
	    public static void main(String[] args) {
	        try {
	            
	            File file = new File("test.txt");
	            if (file.createNewFile()) {
	                System.out.println("File is created: " + file.getName());
	            } else {
	                System.out.println("File is already exists.");
	            }
	            
	            FileWriter writer = new FileWriter(file);
	            writer.write("Hello, world!");
	            writer.close();
	            System.out.println("Successfully wrote to the file.");
	            FileReader reader = new FileReader(file);
	            int character;
	            while ((character = reader.read()) != -1) {
	                System.out.print((char) character);
	            }
	            reader.close();
	            FileWriter writer2 = new FileWriter(file);
	            writer2.write("Goodbye, world!");
	            writer2.close();
	            System.out.println("\nSuccessfully updated the file.");
	            FileReader reader2 = new FileReader(file);
	            int character2;
	            while ((character2 = reader2.read()) != -1) {
	                System.out.print((char) character2);
	            }
	            reader2.close();
	          
	            if (file.delete()) {
	                System.out.println("\nFile deleted: " + file.getName());
	            } else {
	                System.out.println("\nFailed to delete the file.");
	            }
	        } catch (IOException e) {
	            System.out.println("An error occurred: " + e.getMessage());
	            e.printStackTrace();
	        }
	    }
	}

