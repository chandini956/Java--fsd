package practiseproject;
class MyException extends Exception {
    public MyException(String message) {
        super(message);
    }
}

class Calculator {
    public static int divide(int numerator, int denominator) throws MyException {
        if (denominator == 0) {
            throw new MyException("Division by zero!");
        }
        return numerator / denominator;
    }
}

public class Main {
    public static void main(String[] args) {
        int numerator = 10;
        int denominator = 0;
        try {
            int result = Calculator.divide(numerator, denominator);
            System.out.println("Result: " + result);
        } catch (MyException e) {
            System.out.println("Error: " + e.getMessage());
        } finally {
            System.out.println("Finally block  is executed.");
        }
    }
}

