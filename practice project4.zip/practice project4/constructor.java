package practiseproject;

public class constructor {
    private int num1;
    private int num2;
    
    // No-argument constructor
    public constructor() {
        this.num1 = 0;
        this.num2 = 0;
    }
    
    // Parameterized constructor
    public constructor(int num1, int num2) {
        this.num1 = num1;
        this.num2 = num2;
    }
    
    // Copy constructor
    public constructor(constructor other) {
        this.num1 = other.num1;
        this.num2 = other.num2;
    }
    
    public static void main(String[] args) {
        constructor obj1 = new constructor();
        System.out.println("obj1.num1 = " + obj1.num1);
        System.out.println("obj1.num2 = " + obj1.num2);
        
        constructor obj2 = new constructor(10, 20);
        System.out.println("obj2.num1 = " + obj2.num1);
        System.out.println("obj2.num2 = " + obj2.num2);
        
        constructor obj3 = new constructor(obj2);
        System.out.println("obj3.num1 = " + obj3.num1);
        System.out.println("obj3.num2 = " + obj3.num2);
    }
}

