package practiseproject;

class Shape {
    protected double area;
    
    public void calculateArea() {
        System.out.println("Calculating the area of shape...");
    }
    
    public double getArea() {
        return area;
    }
}

class Circle extends Shape {
    private double radius;
    
    public Circle(double radius) {
        this.radius = radius;
    }
    
    @Override
    public void calculateArea() {
        super.calculateArea();
        area = Math.PI * radius * radius;
        System.out.println("Area of circle: " + area);
    }
}

class Rectangle extends Shape {
    private double length;
    private double width;
    
    public Rectangle(double length, double width) {
        this.length = length;
        this.width = width;
    }
    
    @Override
    public void calculateArea() {
        super.calculateArea();
        area = length * width;
        System.out.println("Area of rectangle: " + area);
    }
}

public class objectoriented {
    public static void main(String[] args) {
        Circle circle = new Circle(3);
        circle.calculateArea();
        System.out.println("Circle area: " + circle.getArea());
        
        Rectangle rectangle = new Rectangle(2, 3);
        rectangle.calculateArea();
        System.out.println("Rectangle area: " + rectangle.getArea());
    }
}


