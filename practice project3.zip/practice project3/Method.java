package practiseproject;

public class Method {
    // Method with no arguments and no return type
    public void printMessage() {
        System.out.println("Hello, World!");
    }
    
    // Method with arguments and no return type
    public void printSum(int a, int b) {
        int sum = a + b;
        System.out.println("Sum of " + a + " and " + b + " is " + sum);
    }
    
    // Method with arguments and a return type
    public int findMax(int[] arr) {
        int max = arr[0];
        for (int i = 1; i < arr.length; i++) {
            if (arr[i] > max) {
                max = arr[i];
            }
        }
        return max;
    }
    
    public static void main(String[] args) {
        Method obj = new Method();
        
        // Calling a method with no arguments and no return type
        obj.printMessage();
        
        // Calling a method with arguments and no return type
        obj.printSum(5, 10);
        
        // Calling a method with arguments and a return type
        int[] arr = {10, 20, 30, 40, 50};
        int max = obj.findMax(arr);
        System.out.println("Maximum value in the array is " + max);
    }
}

