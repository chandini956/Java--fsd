package practiseproject;

interface sneha {
    default void greet() {
        System.out.println("Hello from sneha");
    }
}

interface Minni {
    default void greet() {
        System.out.println("Hello from Minni");
    }
}

public class TestClass implements sneha, Minni {
    public void greet() {
        sneha.super.greet(); 
        Minni.super.greet(); 
    }

    public static void main(String[] args) {
        TestClass obj = new TestClass();
        obj.greet(); 
    }
}



		


