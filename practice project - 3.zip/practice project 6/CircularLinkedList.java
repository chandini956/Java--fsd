package practiseproject;
public class CircularLinkedList {
    static class Node {
        int data;
        Node next;
        Node(int value) {
            data = value;
            next = null;
        }
    }
    static Node insertElement(Node head, int newValue) {
        Node newNode = new Node(newValue);

        if (head == null) {
            newNode.next = newNode;
            return newNode;
        }
        Node current = head;
        if (newValue < current.data) {
            while (current.next != head) {
                current = current.next;
            }
            current.next = newNode;
            newNode.next = head;
            return newNode;
        }
        while (current.next != head && current.next.data < newValue) {
            current = current.next;
        }
        newNode.next = current.next;
        current.next = newNode;
        return head;
    }
    static void printList(Node head) {
        if (head == null)
            return;
        Node current = head;
        do {
            System.out.print(current.data + " ");
            current = current.next;
        } while (current != head);
        System.out.println();
    }
    public static void main(String[] args) {
        Node head = null;
        head = insertElement(head, 40);
        head = insertElement(head, 50);
        head = insertElement(head, 60);
        head = insertElement(head, 80);
        System.out.println("Sorted Circular Linked List:");
        printList(head);
    }
}

   
       
