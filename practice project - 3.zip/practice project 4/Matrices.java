package practiseproject;
public class Matrices{
			public static void main(String args[]){
			int a1[][]={{1,2,3},{4,5,6},{2,3,4}};
			int a2[][]={{9,8,7},{6,5,4},{3,2,1}};
			int a[][]=new int[3][3]; 
			for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
			a[i][j]=0;
			for(int k=0;k<3;k++)
			{
			a[i][j]+=a1[i][k]*a2[k][j];
			}
			System.out.print(a[i][j]+" "); 
			}
			System.out.println();
			}
			}
			}