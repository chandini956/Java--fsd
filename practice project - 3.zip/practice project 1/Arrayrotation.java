package practiseproject;
public class Arrayrotation {
	public static void Main(String[] args) {
	}
				public static void leftRotate(int arr[], int d, int n) 
				{ 
				for (int i = 0; i < d; i++) 
				leftRotatebyOne(arr, n); 
				} 	 
				public static void leftRotatebyOne(int arr[], int n) 
				{ 
				int i, temp; 
				temp = arr[0]; 
				for (i = 0; i < n - 1; i++) 
				arr[i] = arr[i + 1]; 
				arr[i] = temp; 
				} 
				public static void main(String[] args) 
				{ 
				int arr[] = { 1, 2, 3, 4, 5, 6, 7 }; 
				int no_of_rotations = 1;
				int n = arr.length;
				System.out.println("Array Elements before rotating : "); 
				for(int i = 0 ; i < n ; i++)
				{
				System.out.print(arr[i]+ " ");
				}
				leftRotate(arr, no_of_rotations, n); 
				System.out.println("\nArray Elements after rotating : "); 
				for(int i = 0 ; i < n ; i++)
				{
				System.out.print(arr[i] + " ");
				} 
				} 
			    }


				 
				

