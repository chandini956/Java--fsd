package practiseproject;
public class SingleLinkedList {
    static class Node {
        int data;
        Node next;
        Node(int value) {
            data = value;
            next = null;
        }
    }
    static Node deleteKey(Node head, int key) {
        if (head == null)
            return null;
        if (head.data == key)
            return head.next;

        Node current = head;
        while (current.next != null) {
            if (current.next.data == key) {
                current.next = current.next.next;
                return head;
            }
            current = current.next;
        }
        return head;
    }
    static void printList(Node head) {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }
    public static void main(String[] args) {
        Node head = new Node(9);
        head.next = new Node(8);
        head.next.next = new Node(7);
        head.next.next.next = new Node(6);
        head.next.next.next.next = new Node(5);
        System.out.println("Original Linked List:");
        printList(head);
        int key = 7;
        head = deleteKey(head, key);
        System.out.println("Linked List after deleting first occurrence of " + key + ":");
        printList(head);
    }
}

