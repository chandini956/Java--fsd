package practiseproject;
import java.util.Scanner;
public class RangeQueries {
		    public static void main(String[] args) {
		        Scanner scanner = new Scanner(System.in);
		        System.out.print("Enter the value of n: ");
		        int n = scanner.nextInt();
		        int[] numbers = new int[n];
		        System.out.println("Enter " + n + " numbers:");
		        for (int i = 0; i < n; i++) {
		            numbers[i] = scanner.nextInt();
		        }
		        System.out.print("Enter the value of L: ");
		        int L = scanner.nextInt();
		        System.out.print("Enter the value of R: ");
		        int R = scanner.nextInt();
		        int sum = 0;
		        if (L >= 0 && R <= n - 1 && L <= R) {
		            for (int i = L; i <= R; i++) {
		                sum += numbers[i];
		            }
		            System.out.println("Sum of elements in the range of L and R: " + sum);
		        } else {
		            System.out.println("Invalid range!");
		        }
		    }
		}
