package practiseproject;
import java.util.Stack;

public class StackExample {
    public static void main(String[] args) {
        Stack<Integer> stack = new Stack<>();
        stack.push(5);
        stack.push(6);
        stack.push(7);
        stack.push(8);
        stack.push(9);

        System.out.println("Stack elements: " + stack);
        int removedElement = stack.pop();
        System.out.println("Removed element: " + removedElement);
        System.out.println("Stack elements after removal: " + stack);
        int topElement = stack.peek();
        System.out.println("Top element: " + topElement);
        System.out.println("Stack elements after peek: " + stack);
    }
}



		