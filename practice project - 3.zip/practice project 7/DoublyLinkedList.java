package practiseproject;
public class DoublyLinkedList {
    static class Node {
        int data;
        Node prev;
        Node next;
        Node(int value) {
            data = value;
            prev = null;
            next = null;
        }
    }
    static void printForward(Node head) {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }
    static void printBackward(Node tail) {
        Node current = tail;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.prev;
        }
        System.out.println();
    }
    public static void main(String[] args) {
        Node head = new Node(9);
        Node second = new Node(8);
        Node third = new Node(7);
        Node fourth = new Node(6);
        head.next = second;
        second.prev = head;
        second.next = third;
        third.prev = second;
        third.next = fourth;
        fourth.prev = third;
        System.out.println("Traversing the doubly linked list in forward direction:");
        printForward(head);
        System.out.println("Traversing the doubly linked list in backward direction:");
        printBackward(fourth);
    }
}
